#ifndef _RPC_RPC_H
#include <sunrpc/rpc/rpc.h>

/* Now define the internal interfaces.  */
extern unsigned long _create_xid (void);

#endif
