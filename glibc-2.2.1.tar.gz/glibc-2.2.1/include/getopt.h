#ifndef _GETOPT_H

#include <posix/getopt.h>

/* Now define the internal interfaces.  */
extern void __getopt_clean_environment (char **__env);

#endif
