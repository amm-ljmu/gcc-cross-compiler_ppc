#ifndef	_LOCALE_H
#include <locale/locale.h>

/* Now define the internal interfaces.  */
extern struct lconv *__localeconv (void);

#endif
