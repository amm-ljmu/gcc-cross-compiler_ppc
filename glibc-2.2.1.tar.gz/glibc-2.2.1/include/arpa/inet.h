#include <inet/arpa/inet.h>

extern in_addr_t __inet_aton (__const char *__cp, struct in_addr *__inp);
