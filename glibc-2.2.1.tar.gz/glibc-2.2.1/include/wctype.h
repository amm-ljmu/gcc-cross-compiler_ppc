#ifndef _WCTYPE_H

#include <wctype/wctype.h>

extern int __iswspace (wint_t __wc);

#endif
