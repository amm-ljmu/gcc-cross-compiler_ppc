#define ENTRY_POINT _start
